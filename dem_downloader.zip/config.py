from __future__ import annotations

import os
from dataclasses import dataclass, field

import yaml


@dataclass
class DemConfig:
    source: str  # 'srtm1' or 'srtm3'

    def __post_init__(self) -> None:
        if self.source not in ("srtm1", "srtm3"):
            raise ValueError(f"dem.source must be 'srtm1' or 'srtm3', got '{self.source}'")


@dataclass
class InputConfig:
    shapefile: str | None = None
    geojson: str | None = None

    def __post_init__(self) -> None:
        pass  # validation deferred to validate()

    def validate(self) -> None:
        provided = []
        if self.shapefile:
            provided.append("shapefile")
        if self.geojson:
            provided.append("geojson")
        if len(provided) != 1:
            raise ValueError(
                f"Exactly one of 'shapefile' or 'geojson' must be provided "
                f"in 'input' section, got {len(provided)}: {provided}"
            )

    @property
    def path(self) -> str:
        return self.shapefile or self.geojson or ""


@dataclass
class OutputConfig:
    directory: str = "./dem_output"
    format: str = "geotiff"

    def __post_init__(self) -> None:
        if self.format not in ("geotiff", "hgt"):
            raise ValueError(
                f"output.format must be 'geotiff' or 'hgt', got '{self.format}'"
            )


@dataclass
class DownloaderConfig:
    opentopography_api_key: str | None = None
    max_workers: int = 4


@dataclass
class Config:
    dem: DemConfig = field(default_factory=lambda: DemConfig(source="srtm3"))
    input: InputConfig = field(default_factory=InputConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    downloader: DownloaderConfig = field(default_factory=DownloaderConfig)

    @classmethod
    def from_yaml(cls, path: str) -> Config:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Config file not found: {path}")
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, dict):
            raise ValueError(f"Invalid YAML config: expected a dict, got {type(data).__name__}")

        raw_dem = data.get("dem", {})
        if not isinstance(raw_dem, dict):
            raise ValueError("'dem' section must be a dict")
        raw_input = data.get("input", {})
        if not isinstance(raw_input, dict):
            raise ValueError("'input' section must be a dict")
        raw_output = data.get("output", {})
        if not isinstance(raw_output, dict):
            raise ValueError("'output' section must be a dict")
        raw_downloader = data.get("downloader", {})
        if not isinstance(raw_downloader, dict):
            raise ValueError("'downloader' section must be a dict")

        cfg = cls(
            dem=DemConfig(source=raw_dem.get("source", "srtm3")),
            input=InputConfig(
                shapefile=raw_input.get("shapefile"),
                geojson=raw_input.get("geojson"),
            ),
            output=OutputConfig(
                directory=raw_output.get("directory", "./dem_output"),
                format=raw_output.get("format", "geotiff"),
            ),
            downloader=DownloaderConfig(
                opentopography_api_key=raw_downloader.get("opentopography_api_key"),
                max_workers=raw_downloader.get("max_workers", 4),
            ),
        )
        # Validate only if input comes from YAML (not CLI override)
        if raw_input.get("shapefile") or raw_input.get("geojson"):
            cfg.input.validate()
        return cfg

    def __str__(self) -> str:
        return (
            f"Config(dem={self.dem.source}, "
            f"input={self.input.path}, "
            f"output={self.output.directory}/{self.output.format}, "
            f"max_workers={self.downloader.max_workers})"
        )
