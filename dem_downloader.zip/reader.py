from __future__ import annotations

import os
from typing import Any

import geopandas as gpd
from shapely.geometry import MultiPolygon, Polygon


def read_vector(
    path: str,
) -> tuple[list[list[tuple[float, float]]], tuple[float, float, float, float]]:
    """Read shapefile or GeoJSON, return polygon coordinates and bounding box.

    Returns:
        (geometries, bbox)
        - geometries: list of polygon rings (each ring is list of (lon, lat) tuples, closed)
        - bbox: (minx, miny, maxx, maxy)
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Input file not found: {path}")

    ext = os.path.splitext(path)[1].lower()
    if ext == ".shp":
        pass  # geopandas auto-detects
    elif ext in (".geojson", ".json"):
        pass
    else:
        raise ValueError(
            f"Unsupported file format: '{ext}'. Supported: .shp, .geojson, .json"
        )

    gdf: gpd.GeoDataFrame = gpd.read_file(path)

    if gdf.empty:
        raise ValueError(f"No features found in {path}")

    # Determine geometry type
    geom_types = gdf.geometry.geom_type.unique()
    has_polygon = any(t in ("Polygon", "MultiPolygon") for t in geom_types)
    if not has_polygon:
        import warnings

        warnings.warn(
            f"Geometry type(s) {list(geom_types)} may not be suitable. "
            f"Expected Polygon/MultiPolygon."
        )

    # Collect exterior coordinates for all polygons
    geometries: list[list[tuple[float, float]]] = []
    for geom in gdf.geometry:
        if geom is None:
            continue
        if isinstance(geom, Polygon):
            coords = list(geom.exterior.coords)
            geometries.append([(x, y) for x, y in coords])
        elif isinstance(geom, MultiPolygon):
            for poly in geom.geoms:
                coords = list(poly.exterior.coords)
                geometries.append([(x, y) for x, y in coords])

    if not geometries:
        raise ValueError(f"No valid Polygon/MultiPolygon geometries found in {path}")

    # Compute total bounding box
    total_bounds: tuple[float, ...] = tuple(gdf.total_bounds)  # (minx, miny, maxx, maxy)
    bbox = (float(total_bounds[0]), float(total_bounds[1]), float(total_bounds[2]), float(total_bounds[3]))

    return geometries, bbox
