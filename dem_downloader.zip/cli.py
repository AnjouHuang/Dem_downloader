from __future__ import annotations

import argparse
import os
import sys

from dem_downloader.config import Config, InputConfig
from dem_downloader.downloader import download_dem


def _detect_input_type(path: str) -> InputConfig:
    """Detect whether the input file is a shapefile or GeoJSON by extension."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".shp":
        return InputConfig(shapefile=path, geojson=None)
    elif ext in (".geojson", ".json"):
        return InputConfig(shapefile=None, geojson=path)
    else:
        raise ValueError(
            f"Unsupported input file extension: '{ext}'. "
            f"Use .shp (shapefile) or .geojson/.json (GeoJSON)"
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="DEM Auto-Downloader - Download SRTM elevation data"
    )
    parser.add_argument(
        "-c",
        "--config",
        required=True,
        help="Path to YAML configuration file",
    )
    parser.add_argument(
        "-i",
        "--input",
        help="Path to input shapefile (.shp) or GeoJSON (.geojson). "
             "Overrides the 'input' section in config file.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose output",
    )
    args = parser.parse_args()

    try:
        config = Config.from_yaml(args.config)

        # CLI -i overrides config's input section
        if args.input:
            config.input = _detect_input_type(args.input)
        config.input.validate()

        if args.verbose:
            print(f"Loaded config: {config}")
        else:
            print(f"Loaded config: {config}")

        output_path = download_dem(config)
        print(f"\nDone! Output: {output_path}")

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)
    except RuntimeError as e:
        print(f"Download error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
