from __future__ import annotations

import math
import os
import shutil
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import requests
from tqdm import tqdm

from dem_downloader.config import Config
from dem_downloader.reader import read_vector

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
OPENTOPOGRAPHY_API = "https://portal.opentopography.org/API/globaldem"

# HGT tile mirror hosted by OpenTopography / SDSC Cloud
HGT_MIRROR = "https://cloud.sdsc.edu/v1/AUTH_opentopography/www"

# Region mapping for SRTM tiles on the SDSC mirror
LAT_TO_REGION: list[tuple[float, float, str]] = [
    (90.0, 55.0, "North_America"),  # Arctic / high north
    (55.0, 25.0, "North_America"),
    (25.0, -10.0, "South_America"),  # Central + South America
    (-10.0, -60.0, "South_America"),
]

LON_TO_REGION: list[tuple[float, float, str]] = [
    (-180.0, -30.0, "South_America"),
    (-30.0, 60.0, "Eurasia"),
    (60.0, 180.0, "Eurasia"),
]

SRTM3_SAMPLES = 1201
SRTM1_SAMPLES = 3601
HGT_CELL_SIZE = 1.0 / (SRTM3_SAMPLES - 1)  # ~0.000833 degrees


def _region_for_tile(lat: int, lon: int) -> str:
    """Map a tile coordinate to its region folder on the SDSC mirror."""
    # Islands region for oceanic tiles
    if abs(lat) <= 5 and (lon < -30 or lon > 60):
        return "Islands"
    if lon < -30:
        return "South_America"
    if lon >= -30 and lon < 60:
        if lat >= 25:
            return "Eurasia"
        elif lat >= -10:
            return "Africa"
        else:
            return "South_America"
    # lon >= 60
    if lat >= 25:
        return "Eurasia"
    elif lat >= -10:
        return "Islands"
    elif lat >= -35:
        return "Australia"
    else:
        return "South_America"


def tile_coord_to_name(lat: int, lon: int) -> str:
    """Convert integer tile coordinates to HGT filename.

    >>> tile_coord_to_name(27, 86) -> 'N27E086.hgt'
    >>> tile_coord_to_name(-33, -70) -> 'S33W070.hgt'
    """
    lat_str = f"N{lat:02d}" if lat >= 0 else f"S{abs(lat):02d}"
    lon_str = f"E{lon:03d}" if lon >= 0 else f"W{abs(lon):03d}"
    return f"{lat_str}{lon_str}.hgt"


def bbox_to_tiles(bbox: tuple[float, float, float, float]) -> list[tuple[int, int]]:
    """Convert a bounding box to a list of (lat_idx, lon_idx) SRTM tile coordinates.

    SRTM tiles are 1°×1°, named by their southwest corner.
    """
    minx, miny, maxx, maxy = bbox
    lon_start = int(math.floor(minx))
    lon_end = int(math.ceil(maxx)) - 1
    lat_start = int(math.floor(miny))
    lat_end = int(math.ceil(maxy)) - 1

    tiles: list[tuple[int, int]] = []
    for lat in range(lat_start, lat_end + 1):
        for lon in range(lon_start, lon_end + 1):
            tiles.append((lat, lon))
    return tiles


def download_hgt_tile(
    lat: int, lon: int, output_dir: str, source: str = "srtm3"
) -> str | None:
    """Download a single SRTM HGT tile from the SDSC mirror.

    Returns the local file path, or None on failure.
    """
    tile_name = tile_coord_to_name(lat, lon)
    local_path = os.path.join(output_dir, tile_name)
    if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
        return local_path  # already downloaded

    region = _region_for_tile(lat, lon)
    srtm_folder = "SRTM3" if source == "srtm3" else "SRTM1"
    url = f"{HGT_MIRROR}/{srtm_folder}/{region}/{tile_name}"

    try:
        resp = requests.get(url, timeout=60)
        if resp.status_code == 200:
            with open(local_path, "wb") as f:
                f.write(resp.content)
            return local_path
        else:
            # Try alternative: different region guess
            alt_regions = [r for r in ["Eurasia", "Africa", "North_America", "South_America", "Australia", "Islands"] if r != region]
            for alt in alt_regions:
                alt_url = f"{HGT_MIRROR}/{srtm_folder}/{alt}/{tile_name}"
                alt_resp = requests.get(alt_url, timeout=60)
                if alt_resp.status_code == 200:
                    with open(local_path, "wb") as f:
                        f.write(alt_resp.content)
                    return local_path
            return None
    except requests.RequestException:
        return None


def merge_hgt_tiles_to_geotiff(
    tile_paths: list[str],
    output_path: str,
    bbox: tuple[float, float, float, float],
) -> str:
    """Merge a list of HGT tiles into a single GeoTIFF, cropped to bbox.

    Uses rasterio.merge for the merge, then crops to the bounding box.
    """
    import rasterio
    from rasterio.merge import merge
    from rasterio.warp import transform_bounds
    from rasterio.crs import CRS

    src_files: list[Any] = []
    for tp in tile_paths:
        try:
            src = rasterio.open(tp)
            src_files.append(src)
        except Exception:
            continue

    if not src_files:
        raise RuntimeError("No valid HGT tiles could be opened for merging")

    # Merge tiles into single raster
    mosaic, out_trans = merge(src_files)

    # Crop to bounding box
    minx, miny, maxx, maxy = bbox
    window = rasterio.windows.from_bounds(minx, miny, maxx, maxy, out_trans)

    # Read the cropped data
    cropped = mosaic[
        :,
        max(0, int(window.row_off)) : min(
            mosaic.shape[1], int(window.row_off + window.height)
        ),
        max(0, int(window.col_off)) : min(
            mosaic.shape[2], int(window.col_off + window.width)
        ),
    ]

    # Update transform for cropped area
    cropped_transform = rasterio.windows.transform(window, out_trans)

    # Write output
    out_meta = src_files[0].meta.copy()
    out_meta.update(
        {
            "driver": "GTiff",
            "height": cropped.shape[1],
            "width": cropped.shape[2],
            "transform": cropped_transform,
            "crs": CRS.from_epsg(4326),
        }
    )

    with rasterio.open(output_path, "w", **out_meta) as dst:
        dst.write(cropped)

    for src in src_files:
        src.close()

    return output_path


def download_dem(config: Config) -> str:
    """Main entry point: download DEM based on config. Returns output file path."""
    os.makedirs(config.output.directory, exist_ok=True)
    input_path = config.input.path
    output_dir = config.output.directory

    # Read input geometry
    geometries, bbox = read_vector(input_path)
    minx, miny, maxx, maxy = bbox
    print(f"Bounding box: {bbox}")

    # Determine tile resolution
    source = config.dem.source  # 'srtm1' or 'srtm3'

    # ---- Strategy 1: Try OpenTopography API first (if key is available) ----
    api_key = config.downloader.opentopography_api_key
    if api_key:
        try:
            return _download_via_opentopography(
                bbox, api_key, source, output_dir
            )
        except Exception as e:
            print(f"OpenTopography API failed ({e}), falling back to HGT tile download...")

    # ---- Strategy 2: HGT tile direct download ----
    return _download_via_hgt_tiles(bbox, source, output_dir, config)


def _download_via_opentopography(
    bbox: tuple[float, float, float, float],
    api_key: str,
    source: str,
    output_dir: str,
) -> str:
    """Download DEM via OpenTopography API (returns merged GeoTIFF)."""
    minx, miny, maxx, maxy = bbox
    dem_type = "SRTMGL3" if source == "srtm3" else "SRTMGL1"

    params: dict[str, Any] = {
        "demtype": dem_type,
        "south": miny,
        "north": maxy,
        "west": minx,
        "east": maxx,
        "outputFormat": "GTiff",
        "API_Key": api_key,
    }

    print("Downloading from OpenTopography API...")
    resp = requests.get(OPENTOPOGRAPHY_API, params=params, timeout=300, stream=True)
    if resp.status_code != 200:
        raise RuntimeError(
            f"OpenTopography API returned status {resp.status_code}: {resp.text[:200]}"
        )

    # Determine output filename
    output_filename = f"dem_{minx:.2f}_{miny:.2f}_{maxx:.2f}_{maxy:.2f}.tif"
    output_path = os.path.join(output_dir, output_filename)

    total = int(resp.headers.get("content-length", 0))
    with tqdm(total=total, unit="B", unit_scale=True, desc="Downloading DEM") as pbar:
        with open(output_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)
                pbar.update(len(chunk))

    print(f"DEM saved to: {output_path}")
    return output_path


def _download_via_hgt_tiles(
    bbox: tuple[float, float, float, float],
    source: str,
    output_dir: str,
    config: Config,
) -> str:
    """Download individual HGT tiles, merge and crop to bbox."""
    minx, miny, maxx, maxy = bbox
    tiles = bbox_to_tiles(bbox)
    print(f"Resolved to {len(tiles)} SRTM tile(s)")

    # Create temp directory for HGT tiles
    tmp_dir = tempfile.mkdtemp(prefix="srtm_")
    try:
        # Download tiles in parallel
        downloaded: list[str] = []
        max_workers = config.downloader.max_workers

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_map = {
                executor.submit(
                    download_hgt_tile, lat, lon, tmp_dir, source
                ): (lat, lon)
                for lat, lon in tiles
            }

            for future in tqdm(
                as_completed(future_map), total=len(tiles), desc="Downloading tiles"
            ):
                lat, lon = future_map[future]
                try:
                    result = future.result()
                    if result:
                        downloaded.append(result)
                    else:
                        print(f"  Warning: failed to download tile {tile_coord_to_name(lat, lon)}")
                except Exception as e:
                    print(f"  Error downloading tile ({lat},{lon}): {e}")

        if not downloaded:
            raise RuntimeError("No HGT tiles could be downloaded. Check internet connection.")

        print(f"Downloaded {len(downloaded)}/{len(tiles)} tiles")

        if config.output.format == "hgt":
            # Just keep the HGT files in the output directory
            for src in downloaded:
                dst = os.path.join(output_dir, os.path.basename(src))
                shutil.copy2(src, dst)
            print(f"HGT files saved to: {output_dir}")
            return output_dir

        # Merge into GeoTIFF
        output_filename = f"dem_{minx:.2f}_{miny:.2f}_{maxx:.2f}_{maxy:.2f}.tif"
        output_path = os.path.join(output_dir, output_filename)

        print("Merging tiles...")
        merge_hgt_tiles_to_geotiff(downloaded, output_path, bbox)
        print(f"Merged DEM saved to: {output_path}")
        return output_path

    finally:
        # Clean up temp tiles
        shutil.rmtree(tmp_dir, ignore_errors=True)
